
# Área administrativa — Sanharo Coxinhas

A área administrativa foi criada em `admin.html`.

Ela permite:
- adicionar produtos;
- alterar nome;
- alterar preço;
- alterar categoria;
- ativar/desativar produto;
- trocar foto;
- excluir produto.

## Para ficar funcionando para você e para os clientes

A versão pública estática precisa de um banco online. Esta versão usa Supabase.

1. Crie um projeto gratuito no Supabase.
2. Em SQL Editor, execute `supabase_setup.sql`.
3. Em Authentication > Users, crie o seu usuário administrador com e-mail e senha.
4. Em Storage, crie um bucket chamado `product-images` e deixe-o público.
5. Copie a URL e a chave `anon` do Supabase.
6. Coloque as duas nos três lugares indicados por `COLOQUE_AQUI...`:
   - `index.html`
   - `app.js`
   - `admin.html`
7. Publique novamente o projeto na Vercel.

Depois:
- seu cliente usa o endereço normal do APP;
- você abre `seu-dominio/admin.html`;
- entra com seu e-mail e senha;
- muda foto, produto e preço;
- as alterações aparecem para os clientes.

Importante: não coloque a chave `service_role` do Supabase no código. Use somente a chave pública `anon`.
