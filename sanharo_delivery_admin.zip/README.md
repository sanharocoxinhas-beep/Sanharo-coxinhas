# Sanharo Coxinhas Delivery

Projeto estático pronto para Vercel.

## Publicar na Vercel
1. Crie um repositório no GitHub e envie estes arquivos.
2. Na Vercel, clique em **Add New > Project**.
3. Importe o repositório.
4. Framework Preset: **Other**.
5. Build Command: deixe vazio.
6. Clique em **Deploy**.

O pedido é enviado para o WhatsApp **(81) 98947-3321**. Edite os produtos e preços no arquivo `app.js`.
