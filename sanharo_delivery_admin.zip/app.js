
const CONFIG = {
  supabaseUrl: "COLOQUE_AQUI_SUA_URL_SUPABASE",
  supabaseAnonKey: "COLOQUE_AQUI_SUA_CHAVE_ANON"
};

const productsFallback = [
  {id:"1",name:"Coxinha de Frango",price:6.99,emoji:"🍗",image:""},
  {id:"2",name:"Coxinha de Frango com Creme Cheese",price:7.99,emoji:"🍗",image:""},
  {id:"3",name:"Coxinha de Charque com Queijo",price:8.99,emoji:"🥟",image:""},
  {id:"4",name:"Coxinha de Costelinha no Barbecue",price:8.99,emoji:"🍖",image:""},
  {id:"5",name:"Pastel de Frango com Queijo",price:8.99,emoji:"🥟",image:""},
  {id:"6",name:"Pastel de Carne com Queijo",price:8.99,emoji:"🥟",image:""},
  {id:"7",name:"Pastel Misto",price:8.99,emoji:"🥟",image:""},
  {id:"8",name:"Pastel Pizza",price:8.99,emoji:"🍕",image:""},
  {id:"9",name:"Guaraná 1 Litro",price:7.00,emoji:"🥤",image:""}
];

let products = [];
let cart = [];
const money = v => Number(v).toLocaleString("pt-BR",{style:"currency",currency:"BRL"});

async function loadProducts(){
  try{
    if(!window.supabaseClient) throw new Error("Supabase não configurado");
    const {data,error} = await window.supabaseClient
      .from("products").select("*").eq("active",true).order("category").order("name");
    if(error) throw error;
    products = data || [];
  }catch(e){
    products = JSON.parse(localStorage.getItem("sanharo_products") || "null") || productsFallback;
  }
  render();
}

function render(){
  const menu = document.getElementById("menu");
  menu.innerHTML = products.map((p,i)=>`
    <article class="card">
      ${p.image ? `<img class="product-img" src="${p.image}" alt="${p.name}">` : `<div class="emoji">${p.emoji||"🍴"}</div>`}
      <h3>${p.name}</h3>
      <div class="price">${money(p.price)}</div>
      <button class="add" onclick="add(${i})">ADICIONAR</button>
    </article>`).join("");
  update();
}

function add(i){
  let x=cart.find(a=>a.i===i);
  x ? x.q++ : cart.push({i,q:1});
  update(); toggleCart();
}
function update(){
  document.getElementById("count").textContent=cart.reduce((s,x)=>s+x.q,0);
  document.getElementById("items").innerHTML=cart.map(x=>`
    <div class="item"><span>${x.q}x ${products[x.i].name}</span><b>${money(products[x.i].price*x.q)}</b></div>`
  ).join("") || "<p>Seu carrinho está vazio.</p>";
  document.getElementById("total").textContent=money(cart.reduce((s,x)=>s+products[x.i].price*x.q,0));
}
function toggleCart(){
  document.getElementById("drawer").classList.toggle("open");
  document.getElementById("overlay").classList.toggle("open");
}
function sendOrder(){
  if(!cart.length)return alert("Adicione itens ao carrinho.");
  const n=document.getElementById("name").value.trim();
  const a=document.getElementById("address").value.trim();
  if(!n||!a)return alert("Informe seu nome e endereço.");
  let text="*NOVO PEDIDO - SANHARO COXINHAS*%0A%0A"+
    cart.map(x=>`${x.q}x ${products[x.i].name} - ${money(products[x.i].price*x.q)}`).join("%0A")+
    `%0A%0A*Total: ${document.getElementById("total").textContent}*%0ACliente: ${n}%0AEndereço: ${a}`;
  location.href="https://wa.me/5581989473321?text="+text;
}
loadProducts();
