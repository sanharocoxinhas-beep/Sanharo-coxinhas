
-- Execute este SQL no SQL Editor do seu projeto Supabase.

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  price numeric(10,2) not null default 0,
  category text default 'Geral',
  emoji text default '🍴',
  image_url text default '',
  active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.products enable row level security;

-- Clientes podem visualizar somente produtos ativos.
create policy "public read active products"
on public.products for select
using (active = true);

-- Administrador autenticado pode administrar tudo.
create policy "authenticated manage products"
on public.products for all
to authenticated
using (true)
with check (true);

insert into public.products (name,price,category,emoji) values
('Coxinha de Frango',6.99,'Coxinhas','🍗'),
('Coxinha de Frango com Creme Cheese',7.99,'Coxinhas','🍗'),
('Coxinha de Charque com Queijo',8.99,'Coxinhas','🥟'),
('Coxinha de Costelinha no Barbecue',8.99,'Coxinhas','🍖'),
('Pastel de Frango com Queijo',8.99,'Pastéis','🥟'),
('Pastel de Carne com Queijo',8.99,'Pastéis','🥟'),
('Pastel Misto',8.99,'Pastéis','🥟'),
('Pastel Pizza',8.99,'Pastéis','🍕'),
('Guaraná 1 Litro',7.00,'Bebidas','🥤');

-- Crie o bucket product-images pela interface Storage do Supabase:
-- Storage > New bucket > product-images > Public.
